package com.example.shifa.patientsList

class Patientsmodel (var pic:Int, var name:String, var id:String)