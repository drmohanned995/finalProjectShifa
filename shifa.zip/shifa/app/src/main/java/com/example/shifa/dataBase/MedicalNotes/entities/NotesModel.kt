package com.example.shifa.dataBase.MedicalNotes

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.sql.Timestamp


@Entity(tableName = "notes_table")
    data class notesModel( //this class will be passed in the repository
        @PrimaryKey
        val NoteId: String,
        val NotePresent: String?,
        val NotePast: String?,
        val NoteLifeStyle: String,
        val NotePatientId:String,
        val NoteDoctorId:String,
        val NoteDate:String
    )
