package com.example.shifa.dataBase.MedicalNotes

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.otherUsersModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef
import com.example.shifa.dataBase.MedicalNotes.relations.doctor.doctorWithPatients
import com.example.shifa.dataBase.User2
import com.example.shifa.dataBase.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class ShifaViewModel(application: Application): AndroidViewModel(application) {

    private val repository: ShifaRepository
    val getAllPatientList: LiveData<List<patientUserModel>>

    init {
        val NoteDao = NotesDatabase.getDatabase(application).notesDao
        repository = ShifaRepository(NoteDao)
        getAllPatientList = repository.getAllPatientList()


     //   getDoctorById = repository.getDoctorById()
    }

  //  val loadDoctorUser: Array<doctorsUserModel>

 /*  init {
        val userDao = NotesDatabase.getDatabase(
            application
        ).notesDao()
        repository = ShifaRepository(userDao)
//        loadDoctorUser = repository.loadDoctorUser(currentUser = AppInfo.currentUser )
    }
*/
    fun addDoctorUser(user: doctorsUserModel){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addDoctorUser(user)
        }}
      suspend fun updateUser(user: doctorsUserModel){
          viewModelScope.launch(Dispatchers.IO) {
         repository.updateUser(user)}
     }

    fun addPatientUser(user: patientUserModel){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addPatientUser(user)
        }
    }
    fun addOthersUser(user: otherUsersModel){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addOthersUser(user)
        }
    }
     fun insertDoctorPatientCrossRif(crossRef: doctor_patient_crossRef){
         viewModelScope.launch(Dispatchers.IO) {
             repository.insertDoctorPatientCrossRif(crossRef)
         }
         }

     fun addNewMessage(user: chatModel){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addNewMessage(user)
        }

    }

    fun addNewNote(newNote: notesModel){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addNewNote(newNote)
        }

    }


    //val getDoctorById: List<doctorsUserModel>

   /* */


    }




