package com.example.shifa.Chat.Database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ChatDatabase(con : Context) : SQLiteOpenHelper(con, "chat.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("create table chat(fr text, rec text,msg text, type integer)")
        db?.execSQL("insert into chat values('me','i44Otksg4ueKvxJxpT4wzlyIaGL2','Good evening',1)")
        db?.execSQL("insert into chat values('i44Otksg4ueKvxJxpT4wzlyIaGL2','me','Hi Yazan',1)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }
}