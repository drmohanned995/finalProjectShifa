package com.example.shifa.report

class reportmodel (var pic:Int, var type:Int , var name:String , varfeed:String)