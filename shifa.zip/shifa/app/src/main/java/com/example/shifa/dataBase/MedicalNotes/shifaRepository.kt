package com.example.shifa.dataBase.MedicalNotes

import androidx.lifecycle.LiveData
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.otherUsersModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef
import com.example.shifa.dataBase.MedicalNotes.relations.doctor.doctorWithPatients
import com.example.shifa.dataBase.User2
import io.reactivex.Flowable

class ShifaRepository (private val noteDao: NoteDao){

    suspend fun addDoctorUser(user: doctorsUserModel){
        noteDao.addNewDoctor(user)
    }
    suspend fun updateUser(user: doctorsUserModel){
        noteDao.updateUser(user)
    }

    suspend fun addPatientUser(user: patientUserModel){
        noteDao.addNewPatient(user)
    }
    suspend fun addOthersUser(user: otherUsersModel){
        noteDao.addNewOthers(user)


    }
    suspend fun addNewNote(newNote: notesModel){
        noteDao.addNewNote(newNote)
    }
    suspend fun getDoctorById(doctorId: String): List<doctorsUserModel> {
        return noteDao.getDoctorById(doctorId)

    }
    suspend fun insertDoctorPatientCrossRif(crossRef: doctor_patient_crossRef){
        noteDao.insertDoctorPatientCrossRif(crossRef)
    }
    suspend fun addNewMessage(user: chatModel){
        noteDao.addNewMessage(user)
    }

    fun getAllPatientList(): LiveData<List<patientUserModel>> {
        return noteDao.getAllPatientList()
    }
 /*   suspend fun getDoctorWithPatients(patientEmail: String):  LiveData<List<doctorWithPatients>>{
        return noteDao.getDoctorWithPatients(patientEmail)
    }*/
}

  /*  fun loadDoctorUser(currentUser:String): Array<doctorsUserModel> {
        return noteDao.loadDoctorUser(currentUser)
    }*/





