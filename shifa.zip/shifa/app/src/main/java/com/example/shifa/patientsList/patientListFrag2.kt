package com.example.shifa.patientsList


import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.shifa.AppInfo.Companion.DoctorUserDetails
//import com.example.shifa.AppInfo.Companion.currentEmail
import com.example.shifa.AppInfo.Companion.currentUser
//import com.example.shifa.AppInfo.Companion.currentPatient
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.UserViewModel
import kotlinx.android.synthetic.main.fragment_patient_list_frag2.*
import kotlinx.coroutines.launch
import kotlin.collections.ArrayList


 class patientListFrag2 : Fragment()  {
    //var list = ArrayList<User2>()
var patientList = ArrayList<patientUserModel>()


    private lateinit var mUserViewModel: UserViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.fragment_patient_list_frag2, container, false)

        loadUserInfo(currentUser)

        println("-----------------------after recycleView $patientList")


        return v
    }

    /*fun onItemClick(position: Int) {
      var currentPatientObj = list[position]
      var patientId = currentPatientObj.id

       //  currentPatient = patientId
        println(list )

       val intent = Intent(context, PatientPage::class.java)

      intent.putExtra("user", list[position] )



        startActivity(intent)



     }*/
     fun loadUserInfo(currentUser: String) {
         val Dao = activity?.let { NotesDatabase.getDatabase(it.applicationContext).notesDao }
         lifecycleScope.launch {

             if (Dao != null) {
                 DoctorUserDetails = Dao.getDoctorById(currentUser)
             }
             // val doctorUsername= AppInfo.DoctorUserDetails.first().doctorUsername
             val currentEmail = DoctorUserDetails.first().doctorEmail
             val dao = activity?.let { NotesDatabase.getDatabase(it.applicationContext).notesDao }
             lifecycleScope.launch {

                 val getPatientsOfDoctor= dao?.getPatientsOfDoctor(currentEmail)?.first()?.patientId

                 if (getPatientsOfDoctor != null) {
                     for (i in getPatientsOfDoctor.indices) {
                         println(i)
                         val patienti = getPatientsOfDoctor[i]
                         patientList.add(patienti)
                         println("---------------------------> "+ patienti)

                     }
                 }
                 val adapter= activity?.let { adapter2(it, patientList) }
                 var adp = adapter
                 patientList_rv.adapter = adp
                 patientList_rv.layoutManager = LinearLayoutManager(activity)
             }

         }
     }
 }
/*
val list:doctorWithPatients= doctorWithPatients(doctorId= ,patientId = )

val patientList<patientUserModel>


[doctorWithPatients
(
doctorId=
doctorsUserModel(doctorEmail=pylori.h@gmail.com, doctorPhone=1, doctorId=2qRabfiHk4MQCcRpYLASKfO32sf2, doctorUsername=mohanned momani),
patientId=
[
patientUserModel(patientEmail=ele@test1, patientPhone=1, patientId=HtKU7zdoT5pV, patientUsername=ale),

  patientUserModel(patientEmail=test2@test2, patientPhone=1, patientId=o6rHlzEVtIp3, patientUsername=eleYacoob)
]
)
]
*/