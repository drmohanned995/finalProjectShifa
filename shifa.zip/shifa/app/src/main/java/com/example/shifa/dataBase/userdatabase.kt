package com.example.shifa.dataBase

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/*
 we need
 @Database
  list of entities
 abstract class that extends RoomDatabase()
 should has an abstract method to return the interface that :@Dao
 */

@Database(entities = [User2::class], version = 3, exportSchema = true)// link database with model
abstract class UserDatabase : RoomDatabase() {

    abstract fun userDao(): patientDao

    companion object {
        @Volatile
        private var INSTANCE: UserDatabase? = null

        fun getDatabase(context: Context): UserDatabase{
            val tempInstance = INSTANCE
            if(tempInstance != null){
                return tempInstance
            }
            synchronized(this){
                val instance = Room.databaseBuilder(context.applicationContext,UserDatabase::class.java,"user_database").
                    fallbackToDestructiveMigration().build()
                INSTANCE = instance
                return instance
            }
        }
    }

}