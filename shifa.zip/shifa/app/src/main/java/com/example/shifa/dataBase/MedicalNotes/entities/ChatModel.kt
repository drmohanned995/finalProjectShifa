package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.annotation.NonNull
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query


@Entity(tableName = "chat_table")
data class chatModel( //this class will be passed in the repository
    @PrimaryKey
    val chatDate: String,
    val chatId: String,
    val chatSender: String?,
    val chatReceiver: String,
    val chatType: String,
    val chatMessage:String,
    val chatPayed:Boolean
)
