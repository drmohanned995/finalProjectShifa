package com.example.shifa.patientProfile

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.shifa.AppInfo
import com.example.shifa.AppInfo.Companion.currentUser
import com.example.shifa.AppInfo.Companion.newlyAddedPatient
import com.example.shifa.Chat.Chat2.chatActivity2
import com.example.shifa.HomeDoctorActivity
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_log_in.*
import kotlinx.android.synthetic.main.fragment_doctor_log_inagainfrag.*
import kotlinx.android.synthetic.main.fragment_doctor_log_inagainfrag.view.*
import kotlinx.coroutines.launch

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [DoctorLogInagainfrag.newInstance] factory method to
 * create an instance of this fragment.
 */
class DoctorLogInagainfrag : DialogFragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
       var v =inflater.inflate(R.layout.fragment_doctor_log_inagainfrag, container, false)
        FirebaseAuth.getInstance().signOut()

       v.frag_loginBtn.setOnClickListener {
           var logIn_userEmail = frag_logIn.text.toString()
           var logIn_password = frag_password.text.toString()

           var auth = FirebaseAuth.getInstance()
           auth.signInWithEmailAndPassword(logIn_userEmail, logIn_password)
               .addOnCompleteListener {
                   if (it.isSuccessful) {

                       currentUser = auth.currentUser!!.uid
                       insertDoctorPatientCrossRif()
                       AppInfo.currentDrEmail = logIn_userEmail
                   }
               }



           val intent = Intent(activity, HomeDoctorActivity::class.java)

           startActivity(intent)


       }


                    return v}

    private  fun insertDoctorPatientCrossRif() {

        var mUserViewModelNote = ViewModelProvider(this).get(ShifaViewModel::class.java)
        lateinit var  DoctorUserDetails:List<doctorsUserModel>
        val Dao = activity?.let { it1 -> NotesDatabase.getDatabase(it1).notesDao }
        lifecycleScope.launch {

            if (Dao != null) {
                DoctorUserDetails = Dao.getDoctorById(currentUser)
            }
            val doctorEmail=DoctorUserDetails[0].doctorEmail
            if (newlyAddedPatient !="null") {
                mUserViewModelNote.insertDoctorPatientCrossRif(
                    doctor_patient_crossRef(
                        doctorEmail,
                        newlyAddedPatient
                    )
                )
            }

        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment DoctorLogInagainfrag.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            DoctorLogInagainfrag().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}