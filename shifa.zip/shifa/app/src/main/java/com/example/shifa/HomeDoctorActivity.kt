package com.example.shifa
import android.content.ContentValues.TAG
import android.content.Context
import java.util.ArrayList

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.shifa.AppInfo.Companion.DoctorUserDetails
//import com.example.shifa.AppInfo.Companion.currentEmail
//import com.example.shifa.AppInfo.Companion.currentEmail
import com.example.shifa.AppInfo.Companion.currentUser
import com.example.shifa.AppInfo.Companion.newlyAddedPatient
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef
import com.example.shifa.dataBase.UserViewModel
import com.example.shifa.patientProfile.DoctorLogInagainfrag
import com.example.shifa.patientProfile.addPatient
import com.example.shifa.patientsList.patientListFrag2

import com.example.shifa.report.reportFrag
import com.google.android.material.tabs.TabLayout
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_home_doctor.*
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import kotlinx.android.synthetic.main.activity_log_in.*
import kotlinx.coroutines.launch

class HomeDoctorActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_doctor)

        //   loadUserInfo(currentUser!!)

        homeDoctor_Greeting.setText(AppInfo.homeDoctorGreeting)
        loadUserInfo(currentUser)
        addDoctorNumber(currentUser)

        homeDoctor_addNewPatient.setOnClickListener {

            startActivity(Intent(this, addPatient::class.java))
        }

        var obj = FBA(supportFragmentManager)
        vp.adapter = obj


        //now to sync viewpager with tabs, u need 2 codes
        vp.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabs)) //when swap tab change
        tabs.addOnTabSelectedListener(TabLayout.ViewPagerOnTabSelectedListener(vp))//when tab change it swaps
    }

    private fun addDoctorNumber(currentUser: String) {


        val Dao = this.let { NotesDatabase.getDatabase(it.applicationContext).notesDao }
        lifecycleScope.launch {
            DoctorUserDetails = Dao.getDoctorById(currentUser)
            val currentPhone = DoctorUserDetails.first().doctorPhone
            if (currentPhone == " ") {
                var obj = AddDoctorPhoneFrag()

                obj.show(this@HomeDoctorActivity.supportFragmentManager, "AddPhone")


            }

           // DoctorUserDetails = Dao.getDoctorById(currentUser)
        }
        // val doctorUsername= AppInfo.DoctorUserDetails.first().doctorUsername

    }


      fun loadUserInfo(currentUser: String) {
          val Dao = NotesDatabase.getDatabase( this).notesDao
          lifecycleScope.launch {

              DoctorUserDetails = Dao.getDoctorById(currentUser)

             val doctorUsername=DoctorUserDetails.first().doctorUsername
              println("------------------------------>$DoctorUserDetails")
           //  currentEmail=DoctorUserDetails.first().doctorEmail
              homeDoctor_Greeting.setText("Welcome Back Dr. $doctorUsername")
  //println("------------------------------>$currentEmail")

            //   insertDoctorPatientCrossRif()



          }

        /*  if (AppInfo.userType ==1){
             // home_Greeting.setText("Welcome Back Dr. $doctorUsername")

              // var loadedInfo =mUserViewModel.loadDoctorUser
              // println("$loadedInfo"+"loaaaaaaaaaaaaaadddddddddddCCcccummmmm")

          }else if (AppInfo.userType ==2){

          }else

              return*/
      }

  /*  private fun insertDoctorPatientCrossRif() {

        var mUserViewModelNote = ViewModelProvider(this).get(ShifaViewModel::class.java)
        lateinit var DoctorUserDetails: List<doctorsUserModel>
        val Dao = NotesDatabase.getDatabase(this).notesDao
        lifecycleScope.launch {

            DoctorUserDetails = Dao.getDoctorById(currentUser)
            val doctorEmail = DoctorUserDetails[0].doctorEmail
            if (newlyAddedPatient == "null") {
                mUserViewModelNote.insertDoctorPatientCrossRif(
                    doctor_patient_crossRef(
                        doctorEmail,
                        newlyAddedPatient
                    )
                )
            }

        }
    }*/

    class FBA(fm: FragmentManager) :
        FragmentPagerAdapter(fm) {//you can do the get count to decide how many frag i want, and getItem to decide who first second and 10th fragment, so the arrangement

        override fun getCount(): Int { //how many frag u want?
            return 2
        }

        override fun getItem(position: Int): Fragment { //here we decide page adapter
            if (position == 0)
                return patientListFrag2()
            else (position == 1)
            return reportFrag()

        }
    }
}

/*
[
doctorsUserModel(doctorEmail=pylori.h@gmail.com, doctorPhone=123456, doctorId=8znqyFQEphbeQCYO8Fn03NT4o1C2,
doctorUsername=mohanned momani)
]
*/