package com.example.shifa.Chat

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.shifa.R
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.rec_img_layout.view.*
import kotlinx.android.synthetic.main.rec_text_layout.view.*
import kotlinx.android.synthetic.main.send_text_layout.view.*
import kotlinx.android.synthetic.main.sent_img_layout.view.*


class ChatAdapter(var con:Context, var list:ArrayList<Chat>) : RecyclerView.Adapter<RecyclerView.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if(viewType == 1)
            return SentTextHolder(LayoutInflater.from(con).inflate(R.layout.send_text_layout,
                parent,false))
        else if(viewType == 2)
            return SentImgHolder(LayoutInflater.from(con).inflate(R.layout.sent_img_layout,
                parent,false))
        else if(viewType == 3)
            return SentLocHolder(LayoutInflater.from(con).inflate(R.layout.send_loc,
                parent,false))

            else if(viewType == 4)
            return RecTextHolder(LayoutInflater.from(con).inflate(R.layout.rec_text_layout,
                parent,false))

             else if(viewType == 5)
            return RecImgHolder(LayoutInflater.from(con).inflate(R.layout.rec_img_layout,
                parent,false))
        else

        return RecLocHolder(LayoutInflater.from(con).inflate(R.layout.send_loc,
            parent,false))
    }


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if(list[position].fr == "mohanned momani")
        {
            if(list[position].type == 1)
                (holder as SentTextHolder).show(list[position].message)
            else if(list[position].type == 2)
                (holder as SentImgHolder).show(list[position].message)
            else
                (holder as SentLocHolder).show(list[position].message)
        }
        else
        {
            if(list[position].type == 1)
                (holder as RecTextHolder).show(list[position].message)
             else if(list[position].type == 2)
                (holder as RecImgHolder).show(list[position].message)
            else
                (holder as RecLocHolder).show(list[position].message)
        }
    }

    override fun getItemCount(): Int {
        return list.size    }

    override fun getItemViewType(position: Int): Int {

        if(list[position].fr == "mohanned momani")
        {
            if(list[position].type == 1)
                return 1 // sent text
            else if (list[position].type == 2)
                return 2 // sent image
            else
                return 3 // sent location
        }
        else
        {

            if(list[position].type == 1)
                return 4 //rec text
            else if (list[position].type == 2)
                return 5 // rec image
            else
                return 6 // rec location
         }


    }

class SentTextHolder(itemView:View) : RecyclerView.ViewHolder(itemView)
{
    fun show(msg:String)
    {
        itemView.sent_msg.text = msg
    }
}

class RecTextHolder(itemView:View) : RecyclerView.ViewHolder(itemView)
{
    fun show(msg:String)
    {
        itemView.rec_msg.text = msg
    }
}

class SentImgHolder(itemView:View) : RecyclerView.ViewHolder(itemView)
{
    fun show(msg:String)
    {
        Picasso.get().load(msg).into(itemView.sent_photo)
    }
}

class RecImgHolder(itemView:View) : RecyclerView.ViewHolder(itemView)
{
    fun show(msg:String)
    {
        Picasso.get().load(msg).into(itemView.rec_photo)
    }
}

class SentLocHolder(itemView:View) : RecyclerView.ViewHolder(itemView)
{
    fun show(msg:String)
    {
        TODO()
        itemView.sent_msg.text = msg
    }
}

class RecLocHolder(itemView:View) : RecyclerView.ViewHolder(itemView)
{
    fun show(msg:String)
    {
        TODO()

        itemView.rec_msg.text = msg
    }
}
}