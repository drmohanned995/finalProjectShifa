package com.example.shifa.dataBase.MedicalNotes.relations.doctor

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.receiptModel
import com.example.shifa.dataBase.MedicalNotes.entities.visitModel


data class doctorWithVisit(
    @Embedded val doctorVisit: doctorsUserModel,
    @Relation(
        parentColumn = "doctorEmail",
        entityColumn=  "visitDoctor"
    )
    val visit: List<visitModel>
)