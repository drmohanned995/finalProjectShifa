package com.example.shifa.Chat


class Chat (var fr:String, var to:String, var message:String, var type:Int)

class message(var date: String, var message:String, var type:Int)