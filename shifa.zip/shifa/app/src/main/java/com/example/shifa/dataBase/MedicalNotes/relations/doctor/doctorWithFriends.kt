package com.example.shifa.dataBase.MedicalNotes.relations.doctor

class doctorWithFriends {
}