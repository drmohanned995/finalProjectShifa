package com.example.shifa.patientProfile

//import com.example.shifa.dataBase.MedicalNotes.shifaViewModel
import android.content.Intent
import android.content.Intent.getIntent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.shifa.AppInfo
import com.example.shifa.AppInfo.Companion.clickedPatientInfo
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.notesModel
import kotlinx.android.synthetic.main.activity_patient_profile2.*
import kotlinx.android.synthetic.main.fragment_patent_present_note.*
import kotlinx.android.synthetic.main.fragment_patent_present_note.view.*
import kotlinx.coroutines.launch
import java.sql.Timestamp

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [patentPresentNoteFrag.newInstance] factory method to
 * create an instance of this fragment.
 */
class patentPresentNoteFrag : Fragment() {
    // private lateinit var mUserViewModel: shifaViewModel
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val v = inflater.inflate(R.layout.fragment_patent_present_note, container, false)




        v.next.setOnClickListener {
            validateAllNoteEntry()

            startActivity(Intent(context, PatientPage::class.java))           // saveNotes()
        //    startActivity(Intent(context, managementFrag2::class.java))


           // openManagementFrag()
        }
        return v
    }

    private fun openManagementFrag() {
        var tr = activity?.supportFragmentManager?.beginTransaction()
        var obj = management_frag() //name of the fragment
        if (tr != null) {
            tr.replace(R.id.home_container, obj)
        }
        if (tr != null) {
            tr.commit()
        }
    }

    private fun saveNotes() {
        lateinit var mUserViewModelNote: ShifaViewModel
        mUserViewModelNote = ViewModelProvider(this).get(ShifaViewModel::class.java)
        lateinit var DoctorUserDetails: List<doctorsUserModel>
        val Dao = activity?.let { NotesDatabase.getDatabase(it).notesDao }
        lifecycleScope.launch {

            if (Dao != null) {
                DoctorUserDetails = Dao.getDoctorById(AppInfo.currentUser)
            }
            val doctorEmail = DoctorUserDetails[0].doctorEmail
           // validateAllNoteEntry(doctorEmail)
        }
    }

    private fun validateAllNoteEntry() {

        val p1 = fragPresentNotes_ChiefComplaint.text.toString()
        val p2 = fragPresentNotes_p2.text.toString()
        val p3 = fragPresentNotes_desa.text.toString()
        val allergy = fragPresentNotes_allergies.text.toString()
        val doctorEmail = "doctorEmail"
        val noteId = generateNoteId()
        val patientEmail=clickedPatientInfo.patientEmail

        if (inputCheck(p1, p2, p3, allergy,doctorEmail,noteId,patientEmail)) {

          //  val Dao = activity?.let { NotesDatabase.getDatabase(it).notesDao }
            val time = System.currentTimeMillis().toInt()
            val tsTemp = Timestamp(time.toLong())
            val ts = tsTemp.toString()
            val NewNote= notesModel(noteId, p1, p2, p3, patientEmail, doctorEmail,ts)


            var mUserViewModelNote: ShifaViewModel = ViewModelProvider(this).get(ShifaViewModel::class.java)
            mUserViewModelNote.addNewNote(NewNote)



            /* Create User Object
            //   val newNote = notesModel(0, p1,p2,p3,allergy)
            // Add Data to Database
              mUserViewModel.addNote(newNote)*/
            Toast.makeText(requireContext(), "Successfully added!", Toast.LENGTH_LONG).show()
            /* Navigate Back
             findNavController().navigate(R.id.action_addFragment_to_listFragment)*/
        } else {
            Toast.makeText(requireContext(), "Please fill out all fields.", Toast.LENGTH_LONG)
                .show()
        }
    }

    private fun generateNoteId(): String {

        val charPool: List<Char> = ('a'..'z') + ('A'..'Z') + ('0'..'9')
        return (1..12)
            .map { kotlin.random.Random.nextInt(0, charPool.size) }
            .map(charPool::get)
            .joinToString("")
    }


    /*  private fun addNewNote(doctorEmail: String) {

        var newNote= notesModel(doctorEmail,"")

        mUserViewModelNote.addPatientUser(newuser)
        lateinit var  NewNoteDetails:List<doctorsUserModel>

    }*/

    private fun inputCheck(
        p1: String,
        p2: String,
        p3: String,
        allergy: String,
        doctorEmail: String,
        noteId: String,
        patientEmail: String
    ): Boolean {
        return !(TextUtils.isEmpty(p1) && TextUtils.isEmpty(p2) && TextUtils.isEmpty(p3) && TextUtils.isEmpty(
            allergy) && TextUtils.isEmpty(doctorEmail) &&TextUtils.isEmpty(noteId) &&TextUtils.isEmpty(patientEmail)

                )
    }


    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment patentPresentNoteFrag.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            patentPresentNoteFrag().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}