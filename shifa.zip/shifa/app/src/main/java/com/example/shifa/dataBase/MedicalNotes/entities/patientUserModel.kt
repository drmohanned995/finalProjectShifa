package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "patient_user_table")
data class patientUserModel ( //this class will be passed in the repository
    @PrimaryKey
    val patientEmail:String,
    val patientPhone:String,
    val patientId: String,
    val patientUsername:String

)
