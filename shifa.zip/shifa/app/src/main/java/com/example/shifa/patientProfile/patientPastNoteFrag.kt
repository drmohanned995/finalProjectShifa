package com.example.shifa.patientProfile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.shifa.AppInfo
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.notesModel
import kotlinx.android.synthetic.main.fragment_patient_past_note.view.*
import kotlinx.coroutines.launch

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [patientPastNoteFrag.newInstance] factory method to
 * create an instance of this fragment.
 */
class patientPastNoteFrag : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.fragment_patient_past_note, container, false)
        // Inflate the layout for this fragment


        var noteList = ArrayList<notesModel>()
        val Dao = activity?.let { NotesDatabase.getDatabase(it.applicationContext).notesDao }
        lifecycleScope.launch {

            if (Dao != null) {
                val getNotesOfPatient = Dao.getNotesOfPatient(AppInfo.clickedPatientInfo.patientEmail).first().notes

                if (getNotesOfPatient != null) {
                    for (i in getNotesOfPatient.indices) {
                        println(i)
                        val patienti = getNotesOfPatient[i]
                        noteList.add(patienti)
                        println("---------------------------> "+ patienti)

                    }
                    val adapter =
                        activity?.let { ArrayAdapter(it, R.layout.past_visits_layout, noteList) }
                    v.note_list.adapter=adapter

                }

            }

    }






       /* lateinit var mUserViewModelNote: ShifaViewModel
        mUserViewModelNote = ViewModelProvider(this).get(ShifaViewModel::class.java)*/
/*
        lateinit var NotesUserDetails: List<notesModel>
        val Dao = activity?.let { NotesDatabase.getDatabase(it.applicationContext).notesDao }
       lifecycleScope.launch {

           if (Dao != null) {
               NotesUserDetails =
                   Dao.getNotesOfPatient(AppInfo.clickedPatientInfo.patientEmail).first().
           }
           println(NotesUserDetails)
       }*/
/*

            val Dao = activity?.let { NotesDatabase.getDatabase(it.applicationContext).notesDao }
            lifecycleScope.launch {
                val patientWithNotes =
                    Dao?.patientWithNotes(AppInfo.clickedPatientInfo.patientEmail, "momanimohanned@gmail.com")?.first()


                println("---------------->>>>>patientnotes $patientWithNotes")




            }


*/

        return v}

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment patientPastNoteFrag.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            patientPastNoteFrag().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}