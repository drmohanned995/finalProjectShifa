package com.example.shifa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.shifa.AppInfo.Companion.greetingText
//import com.example.shifa.AppInfo.Companion.user
import com.example.shifa.AppInfo.Companion.userType
import com.google.firebase.database.FirebaseDatabase

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        main_dr.setOnClickListener{
            startActivity(Intent(this, logInActivity::class.java))
            greetingText = "Welcome Doctor!"
            userType = 1
            //testfirebase()
        }
        main_ptn.setOnClickListener { startActivity(Intent(this, logInActivity::class.java))
            greetingText = "Get well soon!"
            userType = 2
        }
        main_others.setOnClickListener { startActivity(Intent(this, logInActivity::class.java))
            greetingText = "Welcome!"
            userType = 3
        }
    }
/*
    private fun testfirebase() {

        var db= FirebaseDatabase.getInstance().reference
        db.child("Users").child("id").setValue(user)

    }*/
}