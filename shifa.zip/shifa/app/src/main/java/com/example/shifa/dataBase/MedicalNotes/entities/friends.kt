package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.security.CodeSource


@Entity(tableName = "friend")
data class friend (
    @PrimaryKey
    val friendshipId:String,
    val sourceId:String,
    val TargetId:String,
    val TargetType:String
    )
