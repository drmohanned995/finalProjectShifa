package com.example.shifa.dataBase.MedicalNotes.relations.patient

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.notesModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef


data class patientWithDoctors(
    @Embedded val patientId: patientUserModel,
    @Relation(
        parentColumn = "patientId",
        entityColumn= "doctorId",
        associateBy = Junction(doctor_patient_crossRef::class)

    )
    val doctorId: List<doctorsUserModel>
)