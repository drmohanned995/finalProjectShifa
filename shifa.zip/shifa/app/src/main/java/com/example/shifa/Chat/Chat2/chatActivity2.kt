package com.example.shifa.Chat.Chat2

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.shifa.AppInfo
import com.example.shifa.AppInfo.Companion.currentUser
import com.example.shifa.AppInfo.Companion.myLocation
import com.example.shifa.AppInfo.Companion.userType
import com.example.shifa.Chat.Database.MapsFragment
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_chat2.*
import kotlinx.android.synthetic.main.activity_chat2.chat_msg
import kotlinx.android.synthetic.main.activity_chat2.chat_rv
import kotlinx.coroutines.launch
import java.sql.Timestamp
import kotlin.properties.Delegates

class chatActivity2 : AppCompatActivity() {
    private lateinit var mUserViewModel: ShifaViewModel
    var list = ArrayList<chatModel>()
    var dbr = FirebaseDatabase.getInstance().reference
    lateinit var adp: ChatAdapter2
    var  lat by Delegates.notNull<Double>()
    var lon by Delegates.notNull<Double>()
    var thisChatId = makeFirebaseChat()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat2)
       mUserViewModel = ViewModelProvider(this).get(ShifaViewModel::class.java)


        getThisChat(thisChatId)
        adp = ChatAdapter2(this, list)
        chat_rv.adapter = adp
        chat_rv.layoutManager = LinearLayoutManager(this)
        //loc
        if(Build.VERSION.SDK_INT < 23)
            showMyLoc()
        else
            ActivityCompat.requestPermissions(this, arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION),123)


        string_chat_send.setOnClickListener {
           // if (userType == 1) {
                var thisChat = getChatDetailsIfIamTheSender(thisChatId,"string", LatLng(0.0,0.0))

                sendThisMsgToFirebaseAndSaveInDatabase(thisChat)

                sendToAdapter(thisChat)
                // thisChat?.let { it1 -> saveThisMsg(it1) }

                chat_msg.setText("")
           /* } else {
                var thisChat = getChatDetailsIfIamTheSenderPatientPerspective(thisChatId)

                sendThisMsgToFirebaseAndSaveInDatabase(thisChat)

                sendToAdapter(thisChat)
                // thisChat?.let { it1 -> saveThisMsg(it1) }

                chat_msg.setText("")
            }*/
        }

        chat_loc.setOnClickListener {
            showMyLoc()

        }







        dbr.child("users").child(thisChatId).child(AppInfo.currentUser).addValueEventListener(object : ValueEventListener {

            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var msg = snapshot.child("message").value.toString()
                var sender = snapshot.child("sender").value.toString()
                var tp = snapshot.child("type").value.toString()
                var receiver = snapshot.child("receiver").value.toString()
                var timestamp = snapshot.child("Timestamp").value.toString()

                /* var time = System.currentTimeMillis().toInt()
                var tsTemp = Timestamp(time.toLong())
                dbr.currentUser!!.uid +AppInfo.clickedPatientInfo.patientEmail
                 var thisPatientId=AppInfo.clickedPatientInfo.patientEmail
                var ts = tsTemp.toString()*/

                if (sender != AppInfo.currentUser) {
                    var recievedMsg =
                        chatModel(timestamp, thisChatId, sender, receiver, tp, msg, true)
                    if (currentUser!=sender && msg!=null && tp!=null) {
                        mUserViewModel.addNewMessage(recievedMsg)

                        list.add(recievedMsg)
                        adp.notifyDataSetChanged()
                        chat_rv.scrollToPosition(list.size - 1)
                    }
                }
            }
        })
    }

    private fun findMyLocation(lat:Double,lon:Double) {
        var currentLocation = LatLng(lat, lon)
        var thisChat = getChatDetailsIfIamTheSender(thisChatId, "loc", currentLocation)
        sendToAdapter(thisChat)
        sendThisMsgToFirebaseAndSaveInDatabase(thisChat)

    }

    private fun getChatDetailsIfIamTheSenderPatientPerspective(thisChatId: String): chatModel {
      //  var dbr = FirebaseAuth.getInstance()

        //get timestamp
        var time = System.currentTimeMillis().toInt()
        var tsTemp = Timestamp(time.toLong())
        //dbr.currentUser!!.uid +AppInfo.clickedPatientInfo.patientEmail
        //  var thisPatientId=AppInfo.clickedPatientInfo.patientEmail
        var timestamp = tsTemp.toString()

     //   var thisDrId = dbr.currentUser!!.uid

     //   var thisPatientId = AppInfo.clickedPatientInfo.patientId
        var  chatId = thisChatId
        var ChatMessage = chat_msg?.text.toString()
        var chatType = "string"
        var chatSender = AppInfo.currentUser
        var chatReceiver = AppInfo.drPhoneId





        var msg =chatModel(timestamp,chatId,chatSender,chatReceiver,chatType,ChatMessage,true)

        return msg
    }

    private fun getThisChat(thisChatId: String) {
        val dao = NotesDatabase.getDatabase(this).notesDao
        lifecycleScope.launch {
           // lateinit var  thisChatArray:ArrayList<chatModel>
            val getThisChat= dao.getThisChat(thisChatId)

            if (getThisChat != null) {
                for (i in getThisChat.indices) {
                   // println(i)
                    val patienti = getThisChat[i]
                   // list.clear()
                    list.add(patienti)
                    println("---------------------------> "+ patienti)
                    adp.notifyDataSetChanged()
                    chat_rv.scrollToPosition(list.size -1 )
                }
            }
    }
    }
    private fun sendToAdapter(thisChat: chatModel) {
        list.add(thisChat)
        adp.notifyDataSetChanged()
        chat_rv.scrollToPosition(list.size-1)

    }
    private fun makeFirebaseChat(): String {
        if (userType==1){
var chatId= AppInfo.currentUser + AppInfo.clickedPatientInfo.patientId
            dbr.child("users").child(chatId)
                .child("message").setValue("")

            dbr.child("users").child(chatId)
                .child("sender").setValue("")

            dbr.child("users").child(chatId)
                .child("receiver").setValue("")

            dbr.child("users").child(chatId)
                .child("type").setValue("string")

            dbr.child("users").child(chatId)
                .child("timestamp").setValue("")
            return chatId
        }else {
            var chatId= AppInfo.drPhoneId + AppInfo.currentUser
         //   var chatId= AppInfo.chatid TODO()
            dbr.child("users").child(chatId)
                .child("message").setValue("")

            dbr.child("users").child(chatId)
                .child("sender").setValue("")

            dbr.child("users").child(chatId)
                .child("receiver").setValue("")

            dbr.child("users").child(chatId)
                .child("type").setValue("string")

            dbr.child("users").child(chatId)
                .child("timestamp").setValue("")
            return chatId
        }

    }

    private fun getChatDetailsIfIamTheSender(thisChatId: String,chatType:String,currentLoc:LatLng): chatModel {


        var dbr = FirebaseAuth.getInstance()

        //get timestamp
        var time = System.currentTimeMillis().toInt()
        var tsTemp = Timestamp(time.toLong())
        //dbr.currentUser!!.uid +AppInfo.clickedPatientInfo.patientEmail
        //  var thisPatientId=AppInfo.clickedPatientInfo.patientEmail
        var timestamp = tsTemp.toString()

       var thisDrId = dbr.currentUser!!.uid

        var thisPatientId = AppInfo.clickedPatientInfo.patientId
        var  chatId = thisChatId

        var chatType = chatType
        var chatSender = thisDrId
        var chatReceiver = thisPatientId
        if (chatType=="string"){
            var ChatMessage = chat_msg?.text.toString()
            var msg =chatModel(timestamp,chatId,chatSender,chatReceiver,chatType,ChatMessage,true)
            return msg}
        else{
            var ChatMessage=currentLoc
            var msg =chatModel(timestamp,chatId,chatSender,chatReceiver,chatType,"$ChatMessage",true)
            return msg }


    }
  /*  private fun listenToLife(chatId: String, thisDrId: String) {

            dbr.child("users").child(chatId)
                .child("message").addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {

                        var msg = snapshot.child("String").value.toString()
                        var sender = snapshot.child("sender").value.toString()
                        var receiver = snapshot.child("receiver").value.toString()
                        val time = System.currentTimeMillis().toInt()
                        val tsTemp = Timestamp(time.toLong())
                        val ts = tsTemp.toString()

                        list.add( chatModel(chatId,thisDrId,ts, sender, receiver, "string", msg, true))
                        adp.notifyDataSetChanged()
                        chat_msg.setText("")
                        chat_rv.scrollToPosition(list.size - 1)
                    }

                    override fun onCancelled(error: DatabaseError) {
                    }
                })


    }*/
    private fun sendThisMsgToFirebaseAndSaveInDatabase(thisChat: chatModel) {


        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("message").setValue(thisChat.chatMessage)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("sender").setValue(thisChat.chatSender)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("receiver").setValue(thisChat.chatReceiver)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("type").setValue(thisChat.chatType)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("timestamp").setValue(thisChat.chatDate)

        mUserViewModel.addNewMessage(thisChat)
      /*  var sender = snapshot.child("sender").value.toString()
                var tp = snapshot.child("type").value.toString()
                var reciever = snapshot.child("reciever").value.toString()*/
}



    @SuppressLint("MissingPermission")
    fun showMyLoc() {



        var m = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var s = object : LocationListener {
            override fun onLocationChanged(location: Location) {

                lat = location.latitude
                lon = location.longitude


                 myLocation = LatLng(lat, lon)
                findMyLocation(lat, lon)
print("----------------------------->>loc $myLocation")

            }
        }
        m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 385214799, 0f,s)


   }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == 123)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                grantResults[1] == PackageManager.PERMISSION_GRANTED)
                showMyLoc()
           // var loc:LatLng=showMyLoc()
        }
}
}