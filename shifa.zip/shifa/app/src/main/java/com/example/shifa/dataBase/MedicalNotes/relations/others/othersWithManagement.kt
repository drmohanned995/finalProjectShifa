package com.example.shifa.dataBase.MedicalNotes.relations.others

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.managementModel
import com.example.shifa.dataBase.MedicalNotes.entities.otherUsersModel
import com.example.shifa.dataBase.MedicalNotes.entities.receiptModel


data class othersWithManagement(
    @Embedded val othersId: otherUsersModel,
    @Relation(
        parentColumn = "othersEmail",
        entityColumn="othersId"
    )
    val managementOrder: List<managementModel>
)