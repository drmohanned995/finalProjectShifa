package com.example.shifa.patientProfile

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.shifa.R
import com.example.shifa.dataBase.User2
import com.example.shifa.dataBase.UserDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonDisposableHandle.parent
import kotlinx.coroutines.withContext

class patientProfile : AppCompatActivity() {
    class database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient_profile)



    }



}



