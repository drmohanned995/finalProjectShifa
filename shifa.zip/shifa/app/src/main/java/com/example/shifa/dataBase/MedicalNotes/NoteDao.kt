package com.example.shifa.dataBase.MedicalNotes

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.otherUsersModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef
import com.example.shifa.dataBase.MedicalNotes.relations.doctor.doctorWithPatients
import com.example.shifa.dataBase.MedicalNotes.relations.patient.PatientWithNote
import com.example.shifa.dataBase.User2
import io.reactivex.Completable
import io.reactivex.Flowable




@Dao
    interface NoteDao {
        @Insert(onConflict = OnConflictStrategy.IGNORE)
        suspend fun addNewDoctor(user: doctorsUserModel)

        @Update
        suspend fun updateUser(user: doctorsUserModel)


        @Insert(onConflict = OnConflictStrategy.IGNORE)
        suspend fun addNewPatient(user: patientUserModel)


        @Insert(onConflict = OnConflictStrategy.IGNORE)
        suspend fun addNewOthers(user: otherUsersModel)

        @Insert(onConflict = OnConflictStrategy.IGNORE)
        suspend fun addNewNote(newNote: notesModel)


        @Insert(onConflict = OnConflictStrategy.REPLACE)
         suspend fun insertDoctorPatientCrossRif(crossRef: doctor_patient_crossRef)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addNewMessage(user: chatModel)


    @Transaction
         @Query("SELECT * FROM doctor_user_table WHERE doctorEmail = :doctorEmail")
         suspend fun getPatientsOfDoctor(doctorEmail: String): List<doctorWithPatients>

    @Transaction
         @Query("SELECT * FROM chat_table WHERE chatId = :chatId")
         suspend fun getThisChat(chatId: String): List<chatModel>




 @Transaction
    @Query("SELECT * FROM patient_user_table WHERE patientEmail = :patientEmail")
    suspend fun getNotesOfPatient(patientEmail: String): List<PatientWithNote>


/*
    @Transaction
      @Query("SELECT * FROM notes_table WHERE NotePatientId >= :NotePatientId AND NoteDoctorId = :NoteDoctorId ")
      suspend fun getMainContent(NotePatientId: String, NoteDoctorId: String): List<PatientWithNote>
*/
    /* @Transaction
     @Query("SELECT * FROM notes_table WHERE NotePatientId = :patientEmail AND NoteDoctorId = :NoteDoctorId")
     suspend fun patientWithNotes(patientEmail: String, NoteDoctorId:String): List<PatientWithNote>
 */


    /*   @Transaction
       @Query(" SELECT COUNT(*) FROM doctor_patient_crossRef")
       suspend fun getPatientsOfDoctor(doctorEmail: String): List<doctorWithPatients>
  SELECT COUNT(*) FROM cities */


        @Query("SELECT * FROM doctor_user_table WHERE doctorId = :doctorId")
    suspend fun getDoctorById(doctorId: String): List<doctorsUserModel>

    @Query("SELECT * FROM patient_user_table ORDER BY patientUsername ASC")
    fun getAllPatientList(): LiveData<List<patientUserModel>>



}
/*    @Query("SELECT * FROM doctor_user_table" + " WHERE doctorId LIKE :doctorId")
    suspend fun loadDoctorUserById(doctorId: String): List<doctorsUserModel>
*/