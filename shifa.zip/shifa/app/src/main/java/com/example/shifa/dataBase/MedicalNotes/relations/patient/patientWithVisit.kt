package com.example.shifa.dataBase.MedicalNotes.relations.patient

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.receiptModel
import com.example.shifa.dataBase.MedicalNotes.entities.visitModel


data class patientWithVisit(
    @Embedded val patientVisit: patientUserModel,
    @Relation(
        parentColumn = "patientEmail",
        entityColumn=  "visitPatient"
    )
    val visit: List<visitModel>
)