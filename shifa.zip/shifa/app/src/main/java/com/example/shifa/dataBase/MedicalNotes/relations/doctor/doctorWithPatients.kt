package com.example.shifa.dataBase.MedicalNotes.relations.doctor

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef


data class doctorWithPatients(
    @Embedded val doctorId: doctorsUserModel,
    @Relation(
        parentColumn = "doctorEmail",
        entityColumn= "patientEmail",
        associateBy = Junction(doctor_patient_crossRef::class)

    )
    val patientId: List<patientUserModel>
)