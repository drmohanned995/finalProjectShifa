package com.example.shifa.dataBase.MedicalNotes

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.shifa.dataBase.MedicalNotes.entities.*
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_othersRef
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef


@Database(entities = [
    notesModel::class,
    doctorsUserModel::class,
    patientUserModel::class,
    chatModel::class,
    receiptModel::class,
    managementModel::class,
    otherUsersModel::class,
    visitModel::class,
    doctor_othersRef::class,
    doctor_patient_crossRef::class]
        , version = 8,
        exportSchema = true)// link database with model
abstract class NotesDatabase : RoomDatabase() {

    abstract val notesDao: NoteDao

    companion object {
        @Volatile
        private var INSTANCE: NotesDatabase? = null

        fun getDatabase(context: Context): NotesDatabase{
            val tempInstance = INSTANCE
            if(tempInstance != null){
                return tempInstance
            }
            synchronized(this){
                val instance=  Room.
                databaseBuilder(context.applicationContext,NotesDatabase::class.java,"notes_database").
                fallbackToDestructiveMigration().build()
                INSTANCE = instance
                return instance
            }
        }/*

            synchronized(this){
                val instance = Room.databaseBuilder(context.applicationContext,UserDatabase::class.java,"user_database").
                    fallbackToDestructiveMigration().build()
                INSTANCE = instance
                return instance
            }
        }
    }

                }
            }
        }*/
    }

}
