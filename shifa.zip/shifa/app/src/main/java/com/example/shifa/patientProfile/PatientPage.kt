package com.example.shifa.patientProfile

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.bumptech.glide.Glide
import com.example.shifa.AppInfo
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.UserViewModel
import com.google.android.material.tabs.TabLayout
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import com.squareup.picasso.Picasso
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImageView
import kotlinx.android.synthetic.main.activity_patient_profile2.*
import kotlinx.android.synthetic.main.sent_img_layout.view.*

class PatientPage : AppCompatActivity(), TabLayout.OnTabSelectedListener {
    var obj: FragmentPagerAdapter? = null
    var patientInfoInsideProfileActivity=AppInfo.clickedPatientInfo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient_profile2)


       fillPatientDetails(patientInfoInsideProfileActivity)



        imageView3.setOnClickListener {
            CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .start(this )


            /*Intent launchScr = new Intent(this, com.foo.bar.Settings.class);

            var i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(i,123)
      */
        }




        lateinit var mUserViewModel: UserViewModel

         obj=FBA(supportFragmentManager)
        patientProfile_vp.adapter=obj


        //now to sync viewpager with tabs, u need 2 codes
        patientProfile_vp.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(patientProfile_tabs)) //when swap tab change
        patientProfile_tabs.addOnTabSelectedListener(TabLayout.ViewPagerOnTabSelectedListener(patientProfile_vp))//when tab change it swaps
         patientProfile_tabs.addOnTabSelectedListener(this)
    }



    private fun fillPatientDetails(clickedPatientInfo: patientUserModel) {

       patientProfile_patientName.setText(clickedPatientInfo.patientUsername)
        val storage = Firebase.storage

// Reference to an image file in Cloud Storage
        val storageReference = Firebase.storage.reference

// ImageView in your Activity
        val imageView = findViewById<ImageView>(R.id.imageView3)

// Download directly from StorageReference using Glide
// (See MyAppGlideModule for Loader registration)
        Glide.with(this /* context */)
            .load(storageReference)
            .into(imageView)



    }

    class FBA (fm: FragmentManager): FragmentPagerAdapter(fm){//you can do the get count to decide how many frag i want, and getItem to decide who first second and 10th fragment, so the arrangement

        override fun getCount(): Int { //how many frag u want?
            return 3
        }

        override fun getItem(position: Int): Fragment { //here we decide page adapter
            when (position) {
                0 -> return patientProfileFrag()
                1 -> return patientPastNoteFrag()
                else -> (position==2)
            }

                return patentPresentNoteFrag()

        }
    }

    override fun onTabSelected(tab: TabLayout.Tab?) {
        if (tab?.position == 1) {
          var frag =   obj?.getItem(tab?.position) as patientPastNoteFrag
            //frag.fetchNotes(context = applicationContext)
        }
    }

    override fun onTabUnselected(tab: TabLayout.Tab?) {

    }

    override fun onTabReselected(tab: TabLayout.Tab?) {

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            if(resultCode == RESULT_OK)
            {
                var photo = CropImage.getActivityResult(data).uri
                var s = FirebaseStorage.getInstance().reference
                s.child("images").child(patientInfoInsideProfileActivity.patientId+".jpg")
                    .putFile(photo).addOnSuccessListener {
                        it.storage.downloadUrl.addOnSuccessListener {
                            imageView3.setImageURI(photo)
                        }
                    }

       }

    }

    }

    private fun uploadToFirebase(bnp: Bitmap, photo: Uri) {
        var s = FirebaseStorage.getInstance().reference
        s.child("images").
        child(patientInfoInsideProfileActivity.patientId +".jpg").
        putFile(photo).addOnSuccessListener {
            it.storage.downloadUrl.addOnSuccessListener {
                imageView3.setImageURI(it)

            }
        }
        }
    }





