package com.example.shifa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.shifa.AppInfo.Companion.currentDrEmail

import com.example.shifa.AppInfo.Companion.currentUser
import com.example.shifa.AppInfo.Companion.greetingText
import com.example.shifa.AppInfo.Companion.homeDoctorGreeting
import com.example.shifa.AppInfo.Companion.myEmail
import com.example.shifa.AppInfo.Companion.userType
import com.example.shifa.Chat.AppInfoo
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.patientProfile.HomePatientActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_home_doctor.*
import kotlinx.android.synthetic.main.activity_log_in.*
import kotlinx.android.synthetic.main.activity_sign_up.*
import kotlinx.coroutines.launch

class logInActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)

      //  var auth = FirebaseAuth.getInstance()
      //  if (auth.currentUser != null) //this is for the remember me


            test_user.setText(greetingText)

            //AppInfo.my_name = logIn_userEmail.text.toString()
           if (userType == 1) {
               login_btn.setOnClickListener {

                   var auth = FirebaseAuth.getInstance()
                   auth.signInWithEmailAndPassword(
                       logIn_userEmail.text.toString(),
                       logIn_password.text.toString()
                   )
                       .addOnCompleteListener {
                           if (it.isSuccessful) {

                               currentUser = auth.currentUser!!.uid
                         //      makeAddMeOnFirebase(logIn_userEmail.text.toString(), currentUser)
                               addNewDoctor(currentUser)


                               var db = FirebaseDatabase.getInstance().reference
                               db.child("Users").child(AppInfoo.me)
                                   startActivity(Intent(this, HomeDoctorActivity::class.java))

                               loadUserInfo(currentUser)
                           } else
                               Toast.makeText(this, it.exception!!.message, Toast.LENGTH_LONG)
                                   .show()

                       }


               }

           }
           else{
               login_btn.setOnClickListener{
                   var auth = FirebaseAuth.getInstance()
                   auth.signInWithEmailAndPassword(
                       logIn_userEmail.text.toString(),
                       logIn_password.text.toString()
                   )
                       .addOnCompleteListener {
                           if (it.isSuccessful) {
                               startActivity(Intent(this, HomePatientActivity::class.java))
                               currentUser = auth.currentUser!!.uid
                               myEmail=logIn_userEmail.text.toString()
                             //  makeAddMeOnFirebase(logIn_userEmail.text.toString(), currentUser)
                               addNewDoctor(currentUser)
                               loadUserInfo(currentUser)
                           }
                       }
        }
           }
        login_signup.setOnClickListener{
            startActivity(Intent(this, SignUpActivity::class.java))

        }
    }




        private fun addNewDoctor(currentUser: String) {

            var mUserViewModel = ViewModelProvider(this).get(ShifaViewModel::class.java)

            var auth = FirebaseAuth.getInstance()
            var user_id = currentUser
            var email = logIn_userEmail.text.toString()


            //  var username=signup_name.text.toString()
            //  var phone= signup_mobile.text.toString().toInt()


            val newuser = doctorsUserModel(email, " ", user_id, "Doctor")
            currentDrEmail = email
            mUserViewModel.addDoctorUser(newuser)

            Toast.makeText(this, "Added a New Doctor!", Toast.LENGTH_SHORT).show()


        }
    fun loadUserInfo(currentUser: String) {
        val Dao = NotesDatabase.getDatabase( this).notesDao
        lifecycleScope.launch {

            AppInfo.DoctorUserDetails = Dao.getDoctorById(currentUser)

            val doctorUsername= AppInfo.DoctorUserDetails.first().doctorUsername
            println("------------------------------>${AppInfo.DoctorUserDetails}")
            //  currentEmail=DoctorUserDetails.first().doctorEmail
            homeDoctorGreeting="Welcome Back Dr. $doctorUsername"


}
    }
}





