package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "otherUsers_user_table")
data class otherUsersModel ( //this class will be passed in the repository
    @PrimaryKey
    val otherUsersEmail:String,
    val otherUsersPhone:Int,
    val otherUsersId: String,
    val otherUsersUsername:String

)
