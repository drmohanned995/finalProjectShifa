package com.example.shifa.dataBase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.shifa.AppInfo

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class UserViewModel(application: Application): AndroidViewModel(application) {

  //  val currentPatientId: Array<User2>

     val readAllData: LiveData<List<User2>>
    private val repository: UserRepository

 // val readUserById: Array<User2>

    //= userDao.getPatientById(AppInfo.currentPatient)

  //  private val directorDao: patientDao = UserDatabase.getDatabase(application).directorDao()

    init {
        val userDao = UserDatabase.getDatabase(application).userDao()
        repository = UserRepository(userDao)
        readAllData = repository.readAllData()
       // readUserById=repository.readUserById
       // currentPatientId=repository.getPatientById(AppInfo.currentPatient)

    }



    fun addUser(user: User2){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addUser(user)
        }

    }

    }

