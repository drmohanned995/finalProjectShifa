package com.example.shifa.Chat.Database

class chatModel {
}