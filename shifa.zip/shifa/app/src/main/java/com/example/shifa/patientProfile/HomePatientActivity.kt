package com.example.shifa.patientProfile

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.shifa.AppInfo
import com.example.shifa.AppInfo.Companion.chatid
import com.example.shifa.AppInfo.Companion.drPhoneId
import com.example.shifa.Chat.Chat2.chatActivity2
import com.example.shifa.Chat.Chat2.patientChatActivity
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_home_patient.*

class HomePatientActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_patient)




        HomePatient_ChatBtn.setOnClickListener{
            var dbr = FirebaseDatabase.getInstance().reference
            dbr.child("addMe").child(HomePatient_DoctorPhoneNumber.text.toString()).
            addValueEventListener(object: ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                     drPhoneId = snapshot.value.toString()

                    chatid="$drPhoneId+${AppInfo.currentUser}"
                    startActivity(Intent(applicationContext, patientChatActivity::class.java))
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            )



           var mUserViewModelNote = ViewModelProvider(this).get(ShifaViewModel::class.java)
            var newuser= patientUserModel(HomePatient_DoctorPhoneNumber.text.toString(),HomePatient_DoctorPhoneNumber.text.toString(),HomePatient_DoctorPhoneNumber.text.toString(),HomePatient_DoctorPhoneNumber.text.toString())
            mUserViewModelNote.addPatientUser(newuser)

        }


}
}