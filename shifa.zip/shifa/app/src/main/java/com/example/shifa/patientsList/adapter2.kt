package com.example.shifa.patientsList

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.shifa.AppInfo.Companion.clickedPatientInfo
import com.example.shifa.Chat.Chat2.chatActivity2
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.patientProfile.PatientPage
import kotlinx.android.synthetic.main.patient_list.view.*


class adapter2(var con: Context, var list:ArrayList<patientUserModel>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return patientListHolder(LayoutInflater.from(con).inflate(R.layout.patient_list, parent,false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val currentItem = list[position]

        holder.itemView.patient_name.text = currentItem.patientUsername
        holder.itemView.patient_pic.setImageResource(R.drawable.a)
        holder.itemView.paient_menu.setOnClickListener {
            val popupMenu: PopupMenu = PopupMenu(con,holder.itemView.paient_menu)
            popupMenu.menuInflater.inflate(R.menu.recycleview_menu,popupMenu.menu)
            popupMenu.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
                when(item.itemId) {
                    R.id.remove ->{
                        println("remove btn")
                        list.removeAt(position)
                        notifyItemRemoved(position)
                        notifyItemRangeChanged(position,list.size)
                    }

                    R.id.sendMsg ->
                        chat(list[position])

                    R.id.profile->
                        sendInfoToProfile(list[position])



                }
                true
            })
            popupMenu.show()
        }

    }

    private fun sendInfoToProfile(patientUserModel: patientUserModel) {

        clickedPatientInfo = patientUserModel

        val intent = Intent(con, PatientPage::class.java)

        ContextCompat.startActivity(con, intent, null)

      //  Toast.makeText(con, "${patientUserModel.patientUsername}", Toast.LENGTH_SHORT).show()


    }

    private fun chat(patientUsername: patientUserModel) {

        /*val bundle = Bundle()
        bundle.putString("Useremail",patientUsername)

        val fragobj = chatActivity2()
        fragobj.
        var intent = Intent(con,chatActivity2::class.java)

        intent.putExtra("Useremail",patientUsername)

        startActivity(con,intent,null)
        */
        clickedPatientInfo = patientUsername
        val intent = Intent(con, chatActivity2::class.java)

        ContextCompat.startActivity(con, intent, null)
        /*
        val intent = Intent(con,chatActivity2::class.java)
        intent.putExtra("Username", patientUsername)
        startActivity(con,intent,null)*/




        }

    override fun getItemCount(): Int {
        return list.size
    }

}




    class patientListHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        fun show(nm:String, ph:Int, id: Int)
        {

            itemView.patient_name.text = nm
            // itemView.product_price.text = pr.toString()
            itemView.patient_pic.setImageResource(ph)
            // itemView.patient.text = id
        }
    }
