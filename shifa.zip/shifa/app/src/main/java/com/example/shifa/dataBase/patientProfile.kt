package com.example.shifa.dataBase

/*
import java.util.ArrayList

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

/*class patientProfiledb(con: Context) : SQLiteOpenHelper(con, "shifa.db",null,1){
    // chat.db any name as long as .db nullطريفة المزامنة
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("create table patientsProfile(id INTEGER PRIMARY KEY AUTOINCREMENT, name text,email text, phone integer, dob text)")
       // db?.execSQL("insert into patientsProfile values('me','i44Otksg4ueKvxJxpT4wzlyIaGL2\n','Good evening',1)")
      //  db?.execSQL("insert into chat values('i44Otksg4ueKvxJxpT4wzlyIaGL2\n','me','Good evening',1)")

    }

        override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        }}*/

@Parcelize
@Entity(tableName = "user_table") //entity means a table in database

    data class User2(  //this class will be passed in the repository
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val patient_name: String?,
    val patient_picture: Int?,
    val patient_email: String?,
    val patient_phone: Int?,
    val patient_dob: Int?
): Parcelable
*/

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "user_table")
data class User2(
    @PrimaryKey
    val id: String,
    val patient_name: String,
    val patient_picture: Int,
    val patient_email: String,
    val patient_phone: Int,
    val patient_dob: Int
): Parcelable

