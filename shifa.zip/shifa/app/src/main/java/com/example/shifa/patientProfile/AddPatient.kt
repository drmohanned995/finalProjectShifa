package com.example.shifa.patientProfile

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.shifa.AppInfo.Companion.NewUser_name
import com.example.shifa.AppInfo.Companion.currentUser
import com.example.shifa.AppInfo.Companion.newlyAddedPatient

import com.example.shifa.Chat.AppInfoo
import com.example.shifa.HomeDoctorActivity
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_patient_crossRef
import com.example.shifa.dataBase.User2
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_add_patient.*
import kotlinx.coroutines.launch

class addPatient : AppCompatActivity() {
    var auth = FirebaseAuth.getInstance()
    //private lateinit var mUserViewModel:  UserViewModel
    private lateinit var mUserViewModelNote: ShifaViewModel
//lateinit var  userId:String
lateinit var  userId:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_patient)




       // mUserViewModel.readAllData.observe(this, Observer { user -> adapter.setData(user)})
       // mUserViewModel = ViewModelProvider(this).get(UserViewModel::class.java)
        mUserViewModelNote = ViewModelProvider(this).get(ShifaViewModel::class.java)
/*
        var obj=patientProfiledb(this)
        var db=obj.writableDatabase
        //        db?.execSQL("create table patientsProfile(id text, name text,email text, phone integer, dob text)")
        add_btn.setOnClickListener {
            db.execSQL(
                "insert into patientsProfile values (?,?,?,?,? )", arrayOf("123,",
                    add_name.text.toString(),
                    add_email.text.toString(), add_phone.text.toString().toInt(), add_dob.text.toString()



            )
          var cur = db.rawQuery("select * from patientsProfile",null)
            if(cur.count>0){
                cur.moveToFirst()
                var list=ArrayList<String>()
                while (!cur.isAfterLast){
                    list.add(cur.getString(0))
                    cur.moveToNext()
                    println(list)
        }



    }
}
}
*/

        add_btn.setOnClickListener {
            FirebaseAuth.getInstance().signOut();



            addNewPatient()
           // saveNewPatient()

        }

    }

    private fun addNewPatient() {

        val NewUser_email = add_email.text.toString()


         regesterNewPatient(NewUser_email) //online firebase

         signInPatient(NewUser_email)
         insertDoctorPatientCrossRif(NewUser_email)




    }

    private fun signInPatient(NewUser_email:String) {

        auth.signInWithEmailAndPassword(NewUser_email, "123456")
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    userId= auth.currentUser!!.uid

                    addNewPatient2(userId,NewUser_email)


                } else
                    Toast.makeText(this, it.exception!!.message, Toast.LENGTH_LONG).show()
            }

    }

    private fun addNewPatient2(userId: String, NewUser_email: String) {


        val NewUser_Name= add_PatientName.text.toString()
        val NewUser_phone = add_phone.text.toString()
        // var UserId =generateUserId()
        newlyAddedPatient=NewUser_email
          var newuser= patientUserModel(NewUser_email,NewUser_phone,userId,NewUser_Name)

          mUserViewModelNote.addPatientUser(newuser)

     //

        var obj = DoctorLogInagainfrag()

        obj.show(this.supportFragmentManager,"LogIn")

        Toast.makeText(this, "Added a New patient!", Toast.LENGTH_SHORT).show()

       //   startActivity(Intent(this, HomeDoctorActivity::class.java))

    }

    private fun insertDoctorPatientCrossRif(UserId: String) {
        lateinit var  DoctorUserDetails:List<doctorsUserModel>
        val Dao = NotesDatabase.getDatabase(this).notesDao
        lifecycleScope.launch {

            DoctorUserDetails = Dao.getDoctorById(currentUser)
            val doctorEmail=DoctorUserDetails[0].doctorEmail
            mUserViewModelNote.insertDoctorPatientCrossRif(doctor_patient_crossRef(doctorEmail,UserId))

        }
    }

    private fun regesterNewPatient(NewUser_email:String) {



        auth.createUserWithEmailAndPassword(NewUser_email, "123456") //default password for patient is "132456"
            .addOnCompleteListener {

                if(it.isSuccessful) {
                            println("added")

                }

                else
                {Toast.makeText(this, it.exception!!.message, Toast.LENGTH_LONG).show()}
            }


    }

 /*   private fun saveNewPatient() {


         NewUser_name = add_PatientName.text.toString()
        val NewUser_picture= R.drawable.c
        val NewUser_dob = add_dob.text.toString().toInt()
        val NewUser_email = add_email.text.toString()
        val NewUser_phone = add_phone.text.toString().toInt()

        if (inputCheck(NewUser_name, NewUser_picture , NewUser_email ,NewUser_phone,NewUser_dob)) {
            // Create User Object
                // Random.nextInt(12,1000000000)
                   // var recieverUsername =
                    var UserId =generateUserId()
            val newPatient = User2(
                UserId,NewUser_name,Integer.parseInt(NewUser_picture.toString()),NewUser_email,
                NewUser_phone,NewUser_dob)

println("addddddd patiennnnttttt after")


            // Add Data to Database
           // mUserViewModel.addUser(newPatient) //this is the line that saves data inside table
println("addddddd patiennnnttttt after")
            addToFirebase(NewUser_name, "mohanned momani")

println("added a momo")
            startActivity(Intent(this, HomeDoctorActivity::class.java))

        } else {
            Toast.makeText(this, "Please fill out all fields.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addToFirebase(username: String, dr_name: String) {
        var auth = FirebaseAuth.getInstance()
        if(auth.currentUser != null)
        { AppInfoo.me = auth.currentUser!!.uid}
        var db=FirebaseDatabase.getInstance().reference
        db.child("users").child(dr_name).child("message").setValue("")
        db.child("users").child(dr_name).child("sender").setValue(username)
        db.child("users").child(dr_name).child("type").setValue(1)

        addMeToFirebase(dr_name,username)

        println("firebasesssssssssssssssssssssssss $dr_name")
    }

    private fun addMeToFirebase(dr_name: String, username: String) {
        var db=FirebaseDatabase.getInstance().reference
        db.child("users").child(username).child("message").setValue("")
        db.child("users").child(username).child("sender").setValue(dr_name)
        db.child("users").child(username).child("type").setValue(1)    }

    private fun inputCheck(NewUser_name: String,
                           NewUser_picture:Int,
                           NewUser_email: String,
                           NewUser_dob: Int,
                           NewUser_phone: Int): Boolean {
        return !(TextUtils.isEmpty(NewUser_name) && TextUtils.isEmpty(NewUser_dob.toString()) && NewUser_email.isEmpty() &&
                TextUtils.isEmpty(NewUser_phone.toString()) && TextUtils.isEmpty(NewUser_picture.toString()))
    }


    private fun generateUserId(): String {
        val charPool: List<Char> = ('a'..'z') + ('A'..'Z') + ('0'..'9')
        return (1..12)
            .map { kotlin.random.Random.nextInt(0, charPool.size) }
            .map(charPool::get)
            .joinToString("")
    }*/
}

