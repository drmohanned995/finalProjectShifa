package com.example.shifa

import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.User2
import com.example.shifa.patientsList.Patientsmodel
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.FirebaseUser
import kotlin.properties.Delegates

class AppInfo {
    companion object {
        var userType by Delegates.notNull<Int>() //to tell if the user is dr, patient or others

        lateinit var greetingText:String

        lateinit var  currentUser:String
        lateinit var  DoctorUserDetails:List<doctorsUserModel>
     //  lateinit var currentEmail:String
        var homeDoctorGreeting=""
        var chatid=""
 var clickedPatientInfo:patientUserModel = patientUserModel(",",",",",","")
         var my_name="mohanned momani"
    //  lateinit var  userId:String
        lateinit var NewUser_name:String
       var currentDrEmail = ""
 var newlyAddedPatient:String="null"
       var myEmail=""
lateinit var drPhoneId:String
        lateinit var myLocation:LatLng
    }
}