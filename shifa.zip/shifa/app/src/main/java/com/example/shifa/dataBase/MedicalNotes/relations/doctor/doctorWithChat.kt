package com.example.shifa.dataBase.MedicalNotes.relations.doctor

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.notesModel


data class doctorWithChat(
    @Embedded val doctorChat: doctorsUserModel,
    @Relation(
        parentColumn = "doctorEmail",
        entityColumn=  "userChatId"
    )
    val chat: List<chatModel>
)