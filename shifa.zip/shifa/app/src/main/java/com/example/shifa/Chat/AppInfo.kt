package com.example.shifa.Chat

class AppInfoo {
    companion object{
        var me:String = ""
        var friend:String = ""
    }
}