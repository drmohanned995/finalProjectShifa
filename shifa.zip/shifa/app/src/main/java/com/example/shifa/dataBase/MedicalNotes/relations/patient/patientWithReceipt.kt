package com.example.shifa.dataBase.MedicalNotes.relations.patient

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.receiptModel
import com.example.shifa.dataBase.MedicalNotes.notesModel


data class patientWithReceipt(
    @Embedded val patientReceipt: patientUserModel,
    @Relation(
        parentColumn = "patientEmail",
        entityColumn="receiptPayer"
    )
    val receipt: List<receiptModel>
)