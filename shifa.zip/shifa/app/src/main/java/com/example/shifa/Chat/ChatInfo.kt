package com.example.shifa.Chat

class ChatInfo {
}