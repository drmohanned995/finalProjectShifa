package com.example.shifa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope

import com.example.shifa.AppInfo.Companion.userType
import com.example.shifa.dataBase.MedicalNotes.NoteDao
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_sign_up.*
import kotlinx.coroutines.launch
import kotlin.math.log

class SignUpActivity : AppCompatActivity() {

    private lateinit var mUserViewModel: ShifaViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

         mUserViewModel = ViewModelProvider(this).get(ShifaViewModel::class.java)

          signup_btn.setOnClickListener {

              validate1()
        }

}

fun validate1(){
    if(signup_email.text.toString().trim().isEmpty() ||
        signup_password.text.toString().trim().isEmpty()||

       // signup_mobile.text.toString().trim().isEmpty() ||
     //   signup_name.text.toString().trim().isEmpty() ||
        signup_passwordConfirrm.text.toString().trim().isEmpty())

        Toast.makeText(this, "Fill all the fields", Toast.LENGTH_LONG).show()
    else if(signup_password.text.toString() != signup_passwordConfirrm.text.toString())

        Toast.makeText(this, "Password not match", Toast.LENGTH_LONG).show()


    else{
        var auth = FirebaseAuth.getInstance()
        var password=signup_password.text.toString()
        var email= signup_email.text.toString()
     //   var username=signup_name.text.toString()
     //   var phone= signup_mobile.text.toString()
        println("$auth")
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener {
                if(it.isSuccessful)
                {
                    println("account was successful")


                   // addUserToDatabase()
                    startActivity(Intent(this, logInActivity::class.java))
                    println("calling the save user fun")

                   // AppInfo.me = auth.currentUser!!.uid
                //    startActivity(Intent(this, HomeActivity::class.java))
                }
                else
                    Toast.makeText(this, it.exception!!.message, Toast.LENGTH_LONG).show()
            }
    }

}
/*
    private fun addUserToDatabase() {




        var auth = FirebaseAuth.getInstance()
        var user_id = auth.currentUser!!.uid
        var email= signup_email.text.toString()
        var username=signup_name.text.toString()
        var phone= signup_mobile.text.toString().toInt()

        if (userType==1){
            val newuser=doctorsUserModel(email,phone,user_id,username)

            mUserViewModel.addDoctorUser(newuser)

           Toast.makeText(this, "Added a New Doctor!", Toast.LENGTH_SHORT).show()

        }

        else if (userType==2){
            var newuser=patientUserModel(email,phone,user_id,username)

            mUserViewModel.addPatientUser(newuser)
            Toast.makeText(this, "Added a New User!", Toast.LENGTH_SHORT).show()
        }
        else {
            var newuser=patientUserModel(email,phone,user_id,username)

            mUserViewModel.addPatientUser(newuser)
            Toast.makeText(this, "Added a New User!", Toast.LENGTH_SHORT).show()
        }
    }



    fun firebaseAddUser(){
    var auth = FirebaseAuth.getInstance()

    var dbr = FirebaseDatabase.getInstance().reference
    dbr.child("users").child(auth.currentUser!!.uid).child("name")
        .setValue(signup_name.text.toString())
    dbr.child("users").child(auth.currentUser!!.uid).child("message")
        .setValue("hello")
    dbr.child("users").child(auth.currentUser!!.uid).child("type")
        .setValue(1)
}
*/}