package com.example.shifa.patientsList

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.shifa.AppInfo
import com.example.shifa.AppInfo.Companion.NewUser_name
import com.example.shifa.AppInfo.Companion.chatid
import com.example.shifa.Chat.Chat2.chatActivity2
import com.example.shifa.Chat.ChatActivity
import com.example.shifa.Chat.message
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.User2
import kotlinx.android.synthetic.main.new_list_view.view.*
import kotlinx.android.synthetic.main.patient_list.view.*

/*
class patientadapter (var con: Context, var list:ArrayList<User2>,private val listener : onItemClickListener) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

  private var userList = emptyList<User2>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return patientList(LayoutInflater.from(con).inflate(R.layout.patient_list, parent,false))
        }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val currentItem = list[position]

        holder.itemView.patient_name.text = currentItem.patient_name.toString()
        currentItem.patient_picture?.let { holder.itemView.patient_pic.setImageResource(it) }


      /*  list[position].patient_name?.let { list[position].patient_picture?.let { it1 ->
            (holder as patientList).show(it,
                it1,0)*/
       // } }

        holder.itemView.paient_menu.setOnClickListener {
        val popupMenu: PopupMenu = PopupMenu(con,holder.itemView.paient_menu)
        popupMenu.menuInflater.inflate(R.menu.recycleview_menu,popupMenu.menu)
        popupMenu.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
            when(item.itemId) {
                R.id.remove ->{
                    println("remove btn")
                   list.removeAt(position)
                    notifyItemRemoved(position)
                    notifyItemRangeChanged(position,list.size)
                }

                R.id.sendMsg ->
                    chat(list[position].patient_name)

               }
            true
        })
        popupMenu.show()
    }
}

    private fun chat(name: String) {


        NewUser_name= name

        val intent = Intent(con, ChatActivity::class.java)

      //  intent.putExtra("id", id )

       // println("fucking null id $id")
       // AppInfo.chatid=id
        startActivity(con,intent,null)



    }

    override fun getItemCount(): Int {
       return list.size
    }

    inner class patientList(itemView: View) : RecyclerView.ViewHolder(itemView),View.OnClickListener
    {
        fun show(nm:String, ph:Int, id: Int)
        {

            itemView.patient_name.text = nm
           // itemView.product_price.text = pr.toString()
            itemView.patient_pic.setImageResource(ph)
           // itemView.patient.text = id
        }
        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                listener.onItemClick(position)

            }
        }
    }
interface onItemClickListener {
    fun onItemClick(position:Int)


}
    fun setData(user:ArrayList<User2>) {
        this.list = user
        notifyDataSetChanged()

    }
}*/


class patientadapter (var con: Context, var list:ArrayList<patientUserModel>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

  private var userList = emptyList<patientUserModel>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return patientList(LayoutInflater.from(con).inflate(R.layout.patient_list, parent,false))
        }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val currentItem = list[position]

        holder.itemView.patient_name.text = currentItem.patientUsername



        holder.itemView.paient_menu.setOnClickListener {
        val popupMenu: PopupMenu = PopupMenu(con,holder.itemView.paient_menu)
        popupMenu.menuInflater.inflate(R.menu.recycleview_menu,popupMenu.menu)
        popupMenu.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
            when(item.itemId) {
                R.id.remove ->{
                    println("remove btn")
                   list.removeAt(position)
                    notifyItemRemoved(position)
                    notifyItemRangeChanged(position,list.size)
                }

                R.id.sendMsg ->
                    chat(list[position].patientUsername)

               }
            true
        })
        popupMenu.show()
    }
}

    private fun chat(name: String) {


        NewUser_name= name

        val intent = Intent(con, chatActivity2::class.java)

       startActivity(con,intent,null)



    }

    override fun getItemCount(): Int {
       return list.size
    }

    inner class patientList(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        fun show(nm:String, ph:Int, id: Int)
        {

            itemView.patient_name.text = nm
           // itemView.product_price.text = pr.toString()
            itemView.patient_pic.setImageResource(ph)
           // itemView.patient.text = id
        }
       /* init {
            itemView.setOnClickListener(this)
        } */

      /*  override fun onClick(v: View?) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                listener.onItemClick(position)

            }
        }
    }
interface onItemClickListener {
    fun onItemClick(position:Int)


}
    fun setData(user:ArrayList<patientUserModel>) {
        this.list = user
        notifyDataSetChanged()

    }*/
}}


