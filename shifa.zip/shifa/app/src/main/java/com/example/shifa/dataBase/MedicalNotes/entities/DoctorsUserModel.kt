package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "doctor_user_table")
data class doctorsUserModel( //this class will be passed in the repository
    @PrimaryKey
    val doctorEmail: String,
    val doctorPhone:String,
    val doctorId: String,
    val doctorUsername: String?,

)
