package com.example.shifa.Chat


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.shifa.AppInfo.Companion.NewUser_name
import com.example.shifa.AppInfo.Companion.chatid
//import com.example.shifa.AppInfo.Companion.user
import com.example.shifa.R
import com.example.shifa.dataBase.User2
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_chat.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class ChatActivity : AppCompatActivity() {

     var chat_user: String?=""



    lateinit var adp: ChatAdapter
    var list = ArrayList<Chat>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        var dbr = FirebaseDatabase.getInstance().reference
        dbr.child("users").child("mohanned momani").addValueEventListener(object: ValueEventListener{

            override fun onDataChange(snapshot: DataSnapshot) {

                var msg = snapshot.child("message").value.toString()
                var sender = snapshot.child("sender").value.toString()
                var tp = snapshot.child("type").value.toString().toInt()

                if (sender==NewUser_name) {
                    Toast.makeText(applicationContext, "mohanned moamni", Toast.LENGTH_SHORT).show()
                    list.add(Chat(sender, "mohanned momani", msg, tp))
                    adp.notifyDataSetChanged()
                    chat_rv.scrollToPosition(list.size - 1)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })


        adp = ChatAdapter(this, list)
        chat_rv.adapter = adp
        chat_rv.layoutManager = LinearLayoutManager(this)
        chat_rv.scrollToPosition(list.size - 1)

        val user: User2? = intent.getParcelableExtra<User2>("user")
            println("null chat_user $chatid")

        observeChat()
        chat_send.setOnClickListener {
            if(!chat_msg.text.toString().trim().isEmpty()) {

                sendMsgToFirebase(chat_msg.text.toString(), 1, NewUser_name)
                chatRecycleView(chat_msg.text.toString(),NewUser_name)
            }

        }


    }

    private fun observeChat() {

    }

    private fun chatRecycleView(message: String, NewUser_name: String) {
        list.add(Chat("mohanned momani",NewUser_name,message,1))
        adp.notifyDataSetChanged()
        chat_msg.setText("")
        chat_rv.scrollToPosition(list.size - 1)}


    }


    fun sendMsgToFirebase(message: String, i: Int, chatName: String) {

        var dbr = FirebaseDatabase.getInstance().reference
        val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
        val currentDate = sdf.format(Date())

        dbr.child("users").child(chatName)
            .child("message").setValue(message)
        dbr.child("users").child(chatName)
            .child("type").setValue(i)
        dbr.child("users").child(chatName)
            .child("sender").setValue("mohanned momani")



    //.setValue(message(LocalDateTime.now(),toString,i))
        // var db= FirebaseDatabase.getInstance().reference
       // println("is it nullllllllllllllll $chatid")
        /*
        dbr.child("Users").child("id").setValue(AppInfo.user)
         dbr.child("Users").child(user).child("$chatid").child("message")
             .setValue(message(currentDate,message,i))*/
    }
