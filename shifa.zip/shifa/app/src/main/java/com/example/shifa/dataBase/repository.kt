package com.example.shifa.dataBase

import androidx.lifecycle.LiveData
import com.example.shifa.AppInfo

class UserRepository(private val userDao: patientDao) {

    //val readAllData: LiveData<List<User2>> = userDao.readAllData()


//    val readUserById = userDao.getPatientById(AppInfo.currentPatient)
//    val getPatientById: Array<User2> = userDao.getPatientById(AppInfo.currentPatient)


   /* @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addUser(user: User2)
    */

fun readAllData(): LiveData<List<User2>> {
    return userDao.readAllData()
}



    suspend fun addUser(user: User2){
        userDao.addUser(user)
    }

}