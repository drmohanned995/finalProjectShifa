package com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef

import androidx.room.Entity


@Entity(primaryKeys = ["doctorEmail","otherUsersEmail"])
class doctor_othersRef (
    val doctorEmail:String,
    val otherUsersEmail:String

)