package com.example.shifa.dataBase.MedicalNotes.relations.patient

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.patientUserModel
import com.example.shifa.dataBase.MedicalNotes.notesModel

data class PatientWithNote(
    @Embedded val patientNote: patientUserModel,
    @Relation(
        parentColumn = "patientEmail",
        entityColumn="NotePatientId"
    )
    val notes: List<notesModel>
)