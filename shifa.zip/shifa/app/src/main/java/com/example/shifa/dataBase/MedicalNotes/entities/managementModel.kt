package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.room.Entity
import androidx.room.PrimaryKey



@Entity(tableName = "management_table")
data class managementModel( //this class will be passed in the repository
    @PrimaryKey(autoGenerate = true)
    val managementId: Int,
    val othersId:String,
    val managementCounsel : String,
    val managementPrescription: String,
    val prescriptionStatus:Int,
    val managementImaging: String,
    val imagingStatus:Int,
    val managementOthers: String
)
