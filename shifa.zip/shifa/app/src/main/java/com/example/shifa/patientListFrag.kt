package com.example.shifa

/*
// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [patientListFrag.newInstance] factory method to
 * create an instance of this fragment.
 */
class patientListFrag : Fragment(),patientadapter.onItemClickListener {

    private lateinit var mUserViewModel: UserViewModel

    var list = ArrayList<User2>()
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        var v = inflater.inflate(R.layout.fragment_patient_list, container, false)
        /*var list = ArrayList<Patientsmodel>()
        list.add(Patientsmodel( R.drawable.a,"sam Test","8"))
        list.add(Patientsmodel( R.drawable.a,add_name?.text.toString(),"8"))

        var adp = context?.let { patientadapter(it, list,this) }
        rv.adapter=adp
        rv.layoutManager = LinearLayoutManager(requireContext())
*/

//recycle view
        val adapter= context?.let { patientadapter(it,list,this) }
        val recyclerView= v.patientList_rv
        recyclerView.adapter=adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // viewModel
        mUserViewModel = ViewModelProvider(this).get(UserViewModel::class.java)
   //    mUserViewModel.readAllData.observe(viewLifecycleOwner, Observer{ user ->
        //   adapter.setData(list)})
      //  list.add(User( 0,add_name?.text.toString(),
            //R.drawable.a,add_email?.text.toString(),0,0))
        if (adapter != null) {
            adapter.setData(list)
        }
        /*{
        if (adapter != null) {
            adapter.setData(list)
            list.add(Patientsmodel( R.drawable.a,add_name?.text.toString(),"8"))
        }
    })*/
        /*
        list.add(Patientsmodel( R.drawable.a,add_name?.text.toString(),"8"))

     /* list.add(Patientsmodel( R.drawable.a,add_name?.text.toString(),"8"))
        list.add(Patientsmodel(R.drawable.c,"ali", "3" ))
        list.add(Patientsmodel(R.drawable.a,"salem", "1" ))
        list.add(Patientsmodel(R.drawable.b,"aseel", "2" ))
        list.add(Patientsmodel(R.drawable.c,"ali", "3" ))
        list.add(Patientsmodel(R.drawable.a,"salem", "1" ))
        list.add(Patientsmodel(R.drawable.b,"aseel", "2" ))
        list.add(Patientsmodel(R.drawable.c,"ali", "3" ))

        list.add(Patientsmodel( R.drawable.c,add_name?.text.toString(),"0"))*/
        var adp = context?.let { patientadapter(it, list,this) }
        v.rv.adapter=adp
        v.rv.layoutManager= LinearLayoutManager(context)
*/
        return v
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment patientListFrag.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic


        fun newInstance(param1: String, param2: String) =
            patientListFrag().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }





    override fun onItemClick(position: Int) {
        val intent = Intent(context, PatientPage::class.java)

        println(id)

        startActivity(intent)    }


}

*/
