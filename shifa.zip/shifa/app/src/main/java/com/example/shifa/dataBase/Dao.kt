package com.example.shifa.dataBase

import androidx.lifecycle.LiveData
import androidx.room.*


@Dao
    //contains methods to access the database insetr select and delete...etc
    interface patientDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addUser(user: User2)

    @Query("SELECT * FROM user_table ORDER BY id ASC")
    fun readAllData(): LiveData<List<User2>>

    @Query("SELECT * FROM user_table WHERE id = :id")
    fun getPatientById(id:Int): Array<User2>



  /*  @Query("SELECT * FROM user_table WHERE id = :id LIMIT 1")
    suspend fun findDirectorById(id: Long): User2?*/




    /*     @Update
         suspend fun updateUser(user: User2)
 "select * from books where id=?"
         @Delete
         suspend fun deleteUser(user: User2)

         @Query("DELETE FROM user_table")
         suspend fun deleteAllUsers()


@Transaction
    @Query("SELECT * FROM user_table WHERE id = :id")
 fun getPatientById(id:Int):LiveData<List<User2>>

 */
}
