package com.example.shifa.dataBase.MedicalNotes.relations.others

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.doctorsUserModel
import com.example.shifa.dataBase.MedicalNotes.entities.otherUsersModel
import com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef.doctor_othersRef


data class othersWithDoctors(
    @Embedded val othersId: otherUsersModel,
    @Relation(
        parentColumn = "othersEmail",
        entityColumn= "doctorEmail",
        associateBy = Junction(doctor_othersRef::class)

    )
    val doctorId: List<doctorsUserModel>
)