package com.example.shifa.dataBase.MedicalNotes.relations.UsersCrossRef

import androidx.room.Entity

@Entity(primaryKeys = ["doctorEmail","patientEmail"])
class doctor_patient_crossRef (
    val doctorEmail:String,
    val patientEmail:String

        )