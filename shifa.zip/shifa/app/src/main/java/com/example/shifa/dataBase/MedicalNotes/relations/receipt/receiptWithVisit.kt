package com.example.shifa.dataBase.MedicalNotes.relations.receipt

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.example.shifa.dataBase.MedicalNotes.entities.receiptModel
import com.example.shifa.dataBase.MedicalNotes.entities.visitModel


data class receiptWithVisit(
    @Embedded val receipt: receiptModel,
    @Relation(
        parentColumn = "receiptServiceId",
        entityColumn = "visitId"
    )
    val visit: visitModel
)