package com.example.shifa.dataBase.MedicalNotes.relations.receipt

import androidx.room.Embedded
import androidx.room.Relation
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.example.shifa.dataBase.MedicalNotes.entities.receiptModel


data class receiptWithChat(
    @Embedded val receipt: receiptModel,
    @Relation(
        parentColumn = "receiptServiceId",
        entityColumn = "chatId"
    )
    val chat: chatModel
)