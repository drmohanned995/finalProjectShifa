package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "receipt_table")
data class receiptModel ( //this class will be passed in the repository
    @PrimaryKey(autoGenerate = true)
    val receiptId: Int,
    val receiptPayer: String?,
    val receiptReceiver: String?,
    val receiptDate: String,
    val receiptService: String,
    val receiptServiceId: String,
    val receiptAmount:Int
)