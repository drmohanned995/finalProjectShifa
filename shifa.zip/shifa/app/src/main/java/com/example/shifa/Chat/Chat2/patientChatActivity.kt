package com.example.shifa.Chat.Chat2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.shifa.AppInfo
import com.example.shifa.AppInfo.Companion.currentUser
import com.example.shifa.AppInfo.Companion.drPhoneId
import com.example.shifa.R
import com.example.shifa.dataBase.MedicalNotes.NotesDatabase
import com.example.shifa.dataBase.MedicalNotes.ShifaViewModel
import com.example.shifa.dataBase.MedicalNotes.entities.chatModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_chat2.*
import kotlinx.android.synthetic.main.activity_patient_chat.*
import kotlinx.coroutines.launch
import java.sql.Timestamp

class patientChatActivity : AppCompatActivity() {
    var dbr = FirebaseDatabase.getInstance().reference
    lateinit var adp: ChatAdapter2
    var list = ArrayList<chatModel>()
    lateinit var mUserViewModel:ShifaViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient_chat)
        //make id for the chat
        //make first child for the dr to send to and the patient to listen from
        //make another child for the patient to sent to and the dr to listen from
      //  var mUserViewModel = ViewModelProvider(this).get(ShifaViewModel::class.java)
        mUserViewModel = ViewModelProvider(this).get(ShifaViewModel::class.java)
        //make id for the chat




        var thisChatId = makeFirebaseChat()
       // getThisChat(thisChatId)
        adp = ChatAdapter2(this, list)
        chat_rv_patient.adapter = adp
        chat_rv_patient.layoutManager = LinearLayoutManager(this)


        listenToThisChat(thisChatId)
        string_chat_send_Patient.setOnClickListener{

            var thisChat = getChatDetailsIfIamTheSender(thisChatId)

            sendThisMsgToFirebaseAndSaveInDatabase(thisChat)

            sendToAdapter(thisChat)

            chat_msg_Patient.setText("")

        }






    }

    private fun listenToThisChat(thisChatId: String) {

        dbr.child("users").child(thisChatId).child(AppInfo.currentUser).addValueEventListener(object : ValueEventListener {

            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var msg = snapshot.child("message").value.toString()
                var sender = snapshot.child("sender").value.toString()
                var tp = snapshot.child("type").value.toString()
                var receiver = snapshot.child("receiver").value.toString()
                var timestamp = snapshot.child("Timestamp").value.toString()

                /* var time = System.currentTimeMillis().toInt()
                var tsTemp = Timestamp(time.toLong())
                dbr.currentUser!!.uid +AppInfo.clickedPatientInfo.patientEmail
                 var thisPatientId=AppInfo.clickedPatientInfo.patientEmail
                var ts = tsTemp.toString()*/


                    var recievedMsg =
                        chatModel(timestamp, thisChatId, sender, AppInfo.currentUser, tp, msg, true)
                    if (AppInfo.currentUser !=sender) {
                        mUserViewModel.addNewMessage(recievedMsg)
                        println("-----------------------------------> display first msg")
                      //  list.clear()
                        list.add(recievedMsg)
                        adp.notifyDataSetChanged()
                        chat_rv_patient.scrollToPosition(list.size - 1)

                }
            }
        })


    }

    private fun sendToAdapter(thisChat: chatModel) {

        list.add(thisChat)
        adp.notifyDataSetChanged()
        chat_rv_patient.scrollToPosition(list.size-1)
    }

    private fun sendThisMsgToFirebaseAndSaveInDatabase(thisChat: chatModel) {


        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("message").setValue(thisChat.chatMessage)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("sender").setValue(thisChat.chatSender)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("receiver").setValue(thisChat.chatReceiver)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("type").setValue(thisChat.chatType)

        dbr.child("users").child(thisChat.chatId).child(thisChat.chatReceiver)
            .child("timestamp").setValue(thisChat.chatDate)

        mUserViewModel.addNewMessage(thisChat)


    }

    private fun getChatDetailsIfIamTheSender(thisChatId: String): chatModel {


        var dbr = FirebaseAuth.getInstance()

        //get timestamp
        var time = System.currentTimeMillis().toInt()
        var tsTemp = Timestamp(time.toLong())
        //dbr.currentUser!!.uid +AppInfo.clickedPatientInfo.patientEmail
        //  var thisPatientId=AppInfo.clickedPatientInfo.patientEmail
        var timestamp = tsTemp.toString()

        var thisDrId = drPhoneId

        var thisPatientId = currentUser
        var  chatId = thisChatId
        var ChatMessage = chat_msg_Patient?.text.toString()
        var chatType = "string"
        var chatSender = thisPatientId
        var chatReceiver = thisDrId
        var msg =chatModel(timestamp,chatId,chatSender,chatReceiver,chatType,ChatMessage,true)

        return msg



    }

    private fun getThisChat(thisChatId: String) {

        val dao = NotesDatabase.getDatabase(this).notesDao
        lifecycleScope.launch {
            // lateinit var  thisChatArray:ArrayList<chatModel>
            val getThisChat = dao.getThisChat(thisChatId)

            if (getThisChat != null) {
                for (i in getThisChat.indices) {
                    // println(i)
                    val patienti = getThisChat[i]
                    list.add(patienti)
                //    println("---------------------------> " + patienti)
                  //  adp.notifyDataSetChanged()
                  //  chat_rv_patient.scrollToPosition(list?.size - 1)
                }

            }
        }
    }








    private fun makeFirebaseChat(): String {

        var chatId= AppInfo.drPhoneId + AppInfo.currentUser
        //   var chatId= AppInfo.chatid TODO()
        dbr.child("users").child(chatId).child(AppInfo.currentUser)
            .child("message").setValue("")

        dbr.child("users").child(chatId).child(AppInfo.currentUser)
            .child("sender").setValue("")

        dbr.child("users").child(chatId).child(AppInfo.currentUser)
            .child("receiver").setValue("")

        dbr.child("users").child(chatId).child(AppInfo.currentUser)
            .child("type").setValue("string")

        dbr.child("users").child(chatId).child(AppInfo.currentUser)
            .child("timestamp").setValue("")

        return chatId
    }


}