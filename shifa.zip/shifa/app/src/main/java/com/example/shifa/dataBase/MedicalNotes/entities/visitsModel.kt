package com.example.shifa.dataBase.MedicalNotes.entities

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "visit_table")
data class visitModel ( //this class will be passed in the repository
    @PrimaryKey(autoGenerate = true)
    val visitId: Int,
    val visitDoctor: String?,
    val visitPatient: String?,
    val visitDate: String,
    val visitStatus: String, //pending, true,false
    val visitPayed:Boolean

)